<?php
get_header();

$posts_page_id = (int) get_option( 'page_for_posts' );
$all_posts_url = $posts_page_id ? get_permalink( $posts_page_id ) : home_url( '/' );
if ( ! $all_posts_url ) {
    $all_posts_url = home_url( '/' );
}
?>

<main id="primary" class="site-main">
    <?php node_the_breadcrumbs(); ?>

    <section class="m3-surface m3-section-spacing m3-no-posts" aria-labelledby="error-404-title">
        <div class="m3-no-posts__content">
            <span class="material-symbols-outlined m3-no-posts__icon" aria-hidden="true">error</span>
            <h1 id="error-404-title" class="m3-no-posts__title">404 Not Found</h1>
            <p class="m3-no-posts__text">お探しのページは見つかりませんでした。URLが変更されたか、削除された可能性があります。</p>

            <div class="m3-404-actions" style="display:flex;gap:12px;flex-wrap:wrap;justify-content:center;margin-top:16px;">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="m3-button m3-button--filled">ホームへ戻る</a>
                <a href="<?php echo esc_url( $all_posts_url ); ?>" class="m3-button m3-button--text">記事一覧を見る</a>
            </div>

            <div class="m3-404-search" style="margin-top:24px;width:min(560px,100%);">
                <?php get_search_form(); ?>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>
