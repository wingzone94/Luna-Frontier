<?php

declare(strict_types=1);
/**
 * Luminous Core — Hook & Filter Bridge
 *
 * テーマとプラグイン間の疎結合インターフェースを定義する。
 * 各 apply_filters / do_action はプラグインが無効でも安全にフォールバックする。
 *
 * @package Luminous_Core
 * @since   0.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ==========================================================================
   1. AI Core Hooks
   ========================================================================== */

/**
 * AI 要約テキストを取得する。
 *
 * luminous-ai-core プラグインが有効な場合はプラグイン側のフィルタが応答する。
 * 無効な場合は post_meta から直接読み込むフォールバックを提供する。
 *
 * @param int $post_id 投稿ID。
 * @return string AI 要約テキスト（空文字列 = 要約なし）。
 */
function luminous_get_ai_summary( int $post_id ): string {
	$summary = apply_filters( 'luminous_get_ai_summary', '', $post_id );

	// フォールバック: プラグインが未登録の場合、直接メタを参照
	if ( empty( $summary ) ) {
		$summary = get_post_meta( $post_id, '_node_ai_summary', true );
	}

	return is_string( $summary ) ? trim( $summary ) : '';
}

/**
 * 読了時間を取得する。
 *
 * @param int $post_id 投稿ID。
 * @return string 読了時間文字列（例: "3分20秒"）。空文字列 = 未計算。
 */
function luminous_get_reading_time( int $post_id ): string {
	$time = apply_filters( 'luminous_get_reading_time', '', $post_id );

	if ( empty( $time ) ) {
		$time = get_post_meta( $post_id, '_node_reading_time', true );
	}

	return is_string( $time ) ? $time : '';
}

/* ==========================================================================
   2. Nexus Hooks
   ========================================================================== */

/**
 * 記事ヘッダーカードの直後にコンテンツを挿入するアクション。
 *
 * luminous-nexus プラグインが有効な場合、ゲーム情報カードなどを出力する。
 *
 * @param int $post_id 投稿ID。
 */
function luminous_after_article_header( int $post_id ): void {
	do_action( 'luminous_after_article_header', $post_id );
}

/**
 * 記事本文の前にコンテンツを挿入するアクション。
 *
 * @param int $post_id 投稿ID。
 */
function luminous_before_content( int $post_id ): void {
	do_action( 'luminous_before_content', $post_id );
}

/**
 * 記事本文の後にコンテンツを挿入するアクション。
 *
 * @param int $post_id 投稿ID。
 */
function luminous_after_content( int $post_id ): void {
	do_action( 'luminous_after_content', $post_id );
}

/* ==========================================================================
   3. Interactivity Hooks
   ========================================================================== */

/**
 * 投稿が年齢確認ゲートを必要とするかを判定する。
 *
 * @param int $post_id 投稿ID。
 * @return bool true = CERO Z 等の年齢制限コンテンツ。
 */
function luminous_requires_age_gate( int $post_id ): bool {
	$requires = apply_filters( 'luminous_content_requires_age_gate', false, $post_id );

	// フォールバック: プラグインが未登録の場合、直接メタを参照
	if ( ! $requires && ! has_filter( 'luminous_content_requires_age_gate' ) ) {
		$requires = get_post_meta( $post_id, '_node_is_cero_z', true ) === '1';
	}

	return (bool) $requires;
}

/**
 * 年齢確認ダイアログを出力するアクション。
 *
 * luminous-interactivity プラグインが有効な場合にダイアログ HTML を出力する。
 *
 * @param int $post_id 投稿ID。
 */
function luminous_render_age_gate( int $post_id ): void {
	do_action( 'luminous_render_age_gate', $post_id );
}

/* ==========================================================================
   4. Badge / UI Extension Hooks
   ========================================================================== */

/**
 * 投稿バッジ配列をフィルタする。
 *
 * プラグインが独自のバッジ（例: 新着, 人気）を追加できる拡張ポイント。
 *
 * @param array $badges 現在のバッジ配列。
 * @param int   $post_id 投稿ID。
 * @return array フィルタ後のバッジ配列。
 */
function luminous_filter_post_badges( array $badges, int $post_id ): array {
	return apply_filters( 'luminous_post_badges', $badges, $post_id );
}

/**
 * 管理画面のメタボックスフィールドを拡張するフィルタ。
 *
 * @param array $fields 現在のフィールド定義配列。
 * @param int   $post_id 投稿ID。
 * @return array フィルタ後のフィールド配列。
 */
function luminous_filter_card_meta_fields( array $fields, int $post_id ): array {
	return apply_filters( 'luminous_card_meta_fields', $fields, $post_id );
}

/* ==========================================================================
   5. Asset Registration Hook
   ========================================================================== */

/**
 * プラグインがテーマのアセット登録タイミングでスクリプト/スタイルを追加するためのアクション。
 *
 * テーマの `wp_enqueue_scripts` 内から呼び出される。
 */
function luminous_enqueue_plugin_scripts(): void {
	do_action( 'luminous_enqueue_scripts' );
}
/* ==========================================================================
   6. Media & Lightbox Support
   ========================================================================== */

/**
 * 記事内の画像に自動的にメディアファイルへのリンクを付与する。
 * Lightbox プラグインを確実に動作させるためのフィルタ。
 *
 * @param string $content 投稿本文。
 * @return string リンク付与後の本文。
 */
add_filter( 'the_content', 'luminous_auto_image_lightbox_link', 20 );

function luminous_should_auto_lightbox_image( string $image_url ): bool {
    $image_url = trim( $image_url );
    if ( '' === $image_url ) {
        return false;
    }

    $site_host  = wp_parse_url( home_url(), PHP_URL_HOST );
    $image_host = wp_parse_url( $image_url, PHP_URL_HOST );

    if ( is_string( $image_host ) && is_string( $site_host ) && strtolower( $image_host ) !== strtolower( $site_host ) ) {
        return false;
    }

    if ( '' === (string) $image_host && ! str_starts_with( $image_url, '/' ) ) {
        return false;
    }

    $uploads = wp_upload_dir( null, false );
    $baseurl = isset( $uploads['baseurl'] ) ? (string) $uploads['baseurl'] : '';
    $basepath = wp_parse_url( $baseurl, PHP_URL_PATH );
    $image_path = wp_parse_url( $image_url, PHP_URL_PATH );

    return is_string( $basepath )
        && '' !== $basepath
        && is_string( $image_path )
        && str_starts_with( $image_path, trailingslashit( $basepath ) );
}

function luminous_auto_image_lightbox_link( $content ) {
    if ( ! is_singular() ) return $content;

    // <a>タグで囲まれていない <img> タグを探してラップする
    // 1. すでに <a> で囲まれている <img> を一時的に退避
    // 2. 残った <img> を <a> でラップ
    $pattern = '/<a[^>]*>.*?<img[^>]+>.*?<\/a>/is';
    $placeholders = [];
    $content = preg_replace_callback($pattern, function($matches) use (&$placeholders) {
        $placeholder = '<!--M3_LINKED_IMG_' . count($placeholders) . '-->';
        $placeholders[] = $matches[0];
        return $placeholder;
    }, $content);

    // まだリンクされていない画像をラップ
    $img_pattern = '/<img[^>]+src=["\']([^"\']+)["\'][^>]*>/i';
    $content = preg_replace_callback($img_pattern, function($matches) {
        if ( ! luminous_should_auto_lightbox_image( html_entity_decode( $matches[1], ENT_QUOTES, get_bloginfo( 'charset' ) ) ) ) {
            return $matches[0];
        }

        return '<a href="' . esc_url($matches[1]) . '" class="m3-lightbox-link">' . $matches[0] . '</a>';
    }, $content);

    // 退避させていたリンク済み画像を元に戻す
    foreach ($placeholders as $index => $original) {
        $content = str_replace('<!--M3_LINKED_IMG_' . $index . '-->', $original, $content);
    }

    return $content;
}

/**
 * テーマアセット画像を <picture> タグで出力する（WebP優先 + Retina対応）。
 *
 * @param string $filename  assets/images/ 内のファイル名。
 * @param array  $args      属性（alt, class, loading, formats等）。
 */
function node_render_theme_image( string $filename, array $args = [] ): void {
    $base_name = pathinfo( $filename, PATHINFO_FILENAME );
    $ext       = pathinfo( $filename, PATHINFO_EXTENSION );
    $dir_uri   = get_template_directory_uri() . '/assets/images/';
    
    // デフォルトの設定
    $formats = $args['formats'] ?? [ 'webp', $ext ];
    $alt     = $args['alt'] ?? '';
    $class   = $args['class'] ?? '';
    $loading = $args['loading'] ?? 'lazy';

    echo '<picture class="' . esc_attr( $class ) . '">';
    
    foreach ( $formats as $format ) {
        $mime = 'image/' . ( $format === 'jpg' ? 'jpeg' : $format );
        $file_url_1x = $dir_uri . $base_name . '.' . $format;
        $file_url_2x = $dir_uri . $base_name . '@2x.' . $format;
        
        // Retina (2x) 用の記述
        $srcset = esc_url( $file_url_1x ) . ' 1x, ' . esc_url( $file_url_2x ) . ' 2x';

        // 最後の要素（imgタグにフォールバックする形式）以外を <source> として出力
        if ( $format !== $ext || count($formats) > 1 && $format === 'webp' ) {
            echo '<source srcset="' . $srcset . '" type="' . esc_attr( $mime ) . '">';
        }
    }

    /**
     * 最適化プラグインの二重処理を回避する除外クラス/属性
     * - skip-lazy / no-lazy : 遅延読み込みの二重処理を防止
     * - no-webp : WebP変換/Picture化の二重処理を防止 (EWWW等)
     * - data-no-optimize="1" : SG Optimizer等の最適化を防止
     */
    $skip_attrs = 'class="skip-lazy no-lazy no-webp" data-no-optimize="1" data-skip-lazy="1"';

    // 最終的なフォールバック img タグ
    echo '<img src="' . esc_url( $dir_uri . $filename ) . '" alt="' . esc_attr( $alt ) . '" loading="' . esc_attr( $loading ) . '" ' . $skip_attrs . '>';
    echo '</picture>';
}

/* ==========================================================================
   7. Archive Query Adjustments
   ========================================================================== */

/**
 * カテゴリやタグのアーカイブページで、標準の「投稿 (post)」以外の
 * カスタム投稿タイプも表示対象に含める。
 * これにより、カスタム投稿タイプのみが属するカテゴリで404エラーになる問題を修正。
 *
 * @param WP_Query $query
 */
function node_archive_include_cpt( $query ) {
    if ( is_admin() || ! $query->is_main_query() ) {
        return;
    }

    // 検索ページやフロントページでは動作させない（クエリ破壊を防止）
    if ( $query->is_search() || $query->is_home() || $query->is_front_page() ) {
        return;
    }

    // 必ず $query オブジェクトのメソッドを使用して判定する（グローバル関数は使わない）
    if ( $query->is_category() || $query->is_tag() || $query->is_tax() ) {
        // パブリックな投稿タイプをすべて取得
        $post_types = get_post_types( array( 'public' => true ), 'names' );
        
        // アーカイブに含めたくない不要な投稿タイプを除外
        unset( $post_types['page'], $post_types['attachment'] );
        
        $query->set( 'post_type', array_values( $post_types ) );
    }
}
add_action( 'pre_get_posts', 'node_archive_include_cpt' );
/**
 * Remove CAPTCHA and Image Authentication from comment form (e.g. SiteGuard WP Plugin)
 */
function node_remove_comment_captcha_hooks() {
    // SiteGuard WP Plugin
    remove_action( 'comment_form_after_fields', 'siteguard_comment_form_after_fields', 10 );
    remove_action( 'comment_form_logged_in_after', 'siteguard_comment_form_logged_in_after', 10 );
    
    // Really Simple CAPTCHA or others that might use these hooks
    remove_action( 'comment_form_after_fields', 'show_captcha_field', 10 );
}
add_action( 'init', 'node_remove_comment_captcha_hooks' );
