<?php

declare( strict_types=1 );
/**
 * Luna Frontier 2.0 / SkyAlow — AI Summary の二重表示ガード（Phase 4）
 *
 * single モードの Intelligence Summary は Article Header の Paper へ統合済み
 * （template-parts/single/hero.php）。single.php はヒーローの後に改めて
 * この template part を呼ぶため、ここで single モードだけを止める。
 *
 * card モード等は Node 1.x 由来のテンプレートへそのまま委譲する（挙動を変えない）。
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$lf_mode = $args['mode'] ?? 'card';

if ( 'single' === $lf_mode ) {
	return;
}

require get_stylesheet_directory() . '/template-parts/legacy/ai-summary.php';
